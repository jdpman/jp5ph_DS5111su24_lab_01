#__init__.py

from dpy8wq.functions import add_one

from dpy8wq.functions import minus_one
