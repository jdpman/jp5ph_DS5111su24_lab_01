#functions.py


def add_one(x_int):
    return x_int + 1

def minus_one(x_int):
    return x_int - 1
